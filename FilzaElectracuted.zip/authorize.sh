/bootstrap/usr/bin/uicache
/bootstrap/bin/chown root /Applications/Filza.app/FilzaAppstore
/bootstrap/bin/chmod 6777 /Applications/Filza.app/FilzaAppstore